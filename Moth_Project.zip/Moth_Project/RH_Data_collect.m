clear all;
clc;
close all;

s = serialport("/dev/cu.usbmodem14611",9600);
configureTerminator(s,"LF")


i=1

figure(1);hold on;
time = 20;   %time in minutes


while(i<(time*60))
data{i} = readline(s);
splitdata{i} = split(data{i});

subplot(2,1,1)
plot(i,str2double(splitdata{i}(2)),'*');hold on;

subplot(2,1,2)
plot(i,str2double(splitdata{i}(3)),'*');hold on;

i=i+1;
end